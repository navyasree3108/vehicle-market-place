const express = require("express");
const User = require("../models/User");
const Vehicle = require("../models/Vehicle");

const router = express.Router();

// Get all users
router.get("/users", async (req, res) => {
  const users = await User.find();
  res.json(users);
});

// Delete a vehicle
router.delete("/vehicle/:id", async (req, res) => {
  await Vehicle.findByIdAndDelete(req.params.id);
  res.json({ message: "Vehicle deleted" });
});

module.exports = router;
