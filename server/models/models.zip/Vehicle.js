const mongoose = require("mongoose");
const vehicleSchema = new mongoose.Schema({
  make: String,
  model: String,
  year: Number,
  price: Number,
  condition: String,
  mileage: String,
  bodyType: String,
  image: String,
  sellerId: mongoose.Schema.Types.ObjectId
});
module.exports = mongoose.model("Vehicle", vehicleSchema);
