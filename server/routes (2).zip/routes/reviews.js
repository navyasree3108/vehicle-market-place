const express = require("express");
const Review = require("../models/Review");
const router = express.Router();

// Get all reviews
router.get("/", async (req, res) => {
  const reviews = await Review.find();
  res.json(reviews);
});

// Create review
router.post("/", async (req, res) => {
  const review = new Review(req.body);
  await review.save();
  res.json(review);
});

module.exports = router;
