const express = require("express");
const stripe = require("stripe")(process.env.STRIPE_SECRET_KEY);
const mysql = require("mysql2");

const db = mysql.createConnection({
  host: process.env.MYSQL_HOST,
  user: process.env.MYSQL_USER,
  password: process.env.MYSQL_PASSWORD,
  database: process.env.MYSQL_DATABASE
});

db.connect((err) => {
  if (err) throw err;
  console.log("MySQL connected");
});

const router = express.Router();

router.post("/", async (req, res) => {
  const { amount, currency, buyerId, sellerId, vehicleId } = req.body;

  try {
    const paymentIntent = await stripe.paymentIntents.create({
      amount,
      currency
    });

    db.query(
      "INSERT INTO transactions (buyer_id, seller_id, vehicle_id, amount) VALUES (?, ?, ?, ?)",
      [buyerId, sellerId, vehicleId, amount / 100],
      (err, result) => {
        if (err) {
          console.error(err);
          return res.status(500).json({ message: "SQL Error" });
        }
        res.json({ clientSecret: paymentIntent.client_secret });
      }
    );
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Stripe Error" });
  }
});

module.exports = router;
