const mongoose = require("mongoose");
const reviewSchema = new mongoose.Schema({
  buyerId: mongoose.Schema.Types.ObjectId,
  sellerId: mongoose.Schema.Types.ObjectId,
  vehicleId: mongoose.Schema.Types.ObjectId,
  rating: Number,
  comment: String
});
module.exports = mongoose.model("Review", reviewSchema);
